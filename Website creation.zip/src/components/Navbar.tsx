import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [location]);

  const links = [
    { to: "/", label: "Home" },
    { to: "/about", label: "About" },
    { to: "/contact", label: "Contact" },
  ];

  return (
    <nav
      style={{
        background: scrolled ? "rgba(15,23,43,0.98)" : "rgba(15,23,43,0.95)",
        transition: "background 0.4s",
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
        padding: "18px 0",
        boxShadow: scrolled ? "0 2px 20px rgba(0,0,0,0.3)" : "none",
      }}
    >
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Link
          to="/"
          style={{ textDecoration: "none", display: "flex", alignItems: "center", gap: 10, fontSize: 28, fontWeight: 700, color: "#FEA116" }}
        >
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" />
            <path d="M7 2v20" />
            <path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7" />
          </svg>
          Beef With Chef Melbin
        </Link>

        {/* Desktop nav */}
        <div style={{ display: "flex", alignItems: "center", gap: 8 }} className="desktop-nav">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              style={{
                color: location.pathname === l.to ? "#FEA116" : "#fff",
                textDecoration: "none",
                fontWeight: 500,
                padding: "6px 16px",
                fontSize: 15,
                transition: "color 0.3s",
              }}
              onMouseEnter={(e) => { (e.target as HTMLElement).style.color = "#FEA116"; }}
              onMouseLeave={(e) => { (e.target as HTMLElement).style.color = location.pathname === l.to ? "#FEA116" : "#fff"; }}
            >
              {l.label}
            </Link>
          ))}
          <Link
            to="/login"
            style={{
              background: "#FEA116",
              color: "#fff",
              textDecoration: "none",
              padding: "10px 24px",
              borderRadius: 8,
              fontWeight: 600,
              fontSize: 15,
              marginLeft: 12,
              transition: "background 0.3s",
            }}
            onMouseEnter={(e) => { (e.target as HTMLElement).style.background = "#e08a00"; }}
            onMouseLeave={(e) => { (e.target as HTMLElement).style.background = "#FEA116"; }}
          >
            Login
          </Link>
        </div>

        {/* Mobile hamburger */}
        <button
          onClick={() => setOpen(!open)}
          style={{ background: "none", border: "none", cursor: "pointer", padding: 8, display: "none" }}
          className="mobile-menu-btn"
          aria-label="Toggle menu"
        >
          <div style={{ width: 24, height: 2, background: "#fff", marginBottom: 5, transition: "0.3s" }} />
          <div style={{ width: 24, height: 2, background: "#fff", marginBottom: 5, transition: "0.3s" }} />
          <div style={{ width: 24, height: 2, background: "#fff", transition: "0.3s" }} />
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div style={{ background: "rgba(15,23,43,0.99)", padding: "16px 24px 24px" }}>
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              style={{ display: "block", color: location.pathname === l.to ? "#FEA116" : "#fff", textDecoration: "none", padding: "10px 0", fontWeight: 500, fontSize: 16 }}
            >
              {l.label}
            </Link>
          ))}
          <Link
            to="/login"
            style={{ display: "inline-block", marginTop: 12, background: "#FEA116", color: "#fff", textDecoration: "none", padding: "10px 24px", borderRadius: 8, fontWeight: 600 }}
          >
            Login
          </Link>
        </div>
      )}

      <style>{`
        @media (max-width: 768px) {
          .desktop-nav { display: none !important; }
          .mobile-menu-btn { display: block !important; }
        }
      `}</style>
    </nav>
  );
}
