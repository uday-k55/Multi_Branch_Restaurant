import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer style={{ background: "#0F172B", color: "#fff", padding: "70px 0 0" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 40 }}>
          {/* Brand */}
          <div>
            <h3 style={{ color: "#FEA116", fontSize: 22, fontWeight: 700, marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" /><path d="M7 2v20" /><path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7" />
              </svg>
              Beef With Chef Melbin
            </h3>
            <p style={{ color: "#ccc", lineHeight: 1.7, fontSize: 15 }}>
              Enjoy delicious food with Dine-In, Home Delivery, Takeaway and QR Table Ordering.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h5 style={{ marginBottom: 20, fontWeight: 600, fontSize: 16 }}>Quick Links</h5>
            {[["Home", "/"], ["About", "/about"], ["Contact", "/contact"], ["Login", "/login"]].map(([label, to]) => (
              <Link
                key={to}
                to={to}
                style={{ display: "block", color: "#ddd", textDecoration: "none", marginBottom: 10, fontSize: 15, transition: "color 0.3s" }}
                onMouseEnter={(e) => { (e.target as HTMLElement).style.color = "#FEA116"; }}
                onMouseLeave={(e) => { (e.target as HTMLElement).style.color = "#ddd"; }}
              >
                {label}
              </Link>
            ))}
          </div>

          {/* Contact */}
          <div>
            <h5 style={{ marginBottom: 20, fontWeight: 600, fontSize: 16 }}>Contact</h5>
            {[
              { icon: "📍", text: "Kottayam, Kerala" },
              { icon: "📞", text: "+91 9876543210" },
              { icon: "✉️", text: "info@chefmelbin.com" },
            ].map((item) => (
              <p key={item.text} style={{ color: "#ddd", marginBottom: 10, fontSize: 15, display: "flex", alignItems: "flex-start", gap: 8 }}>
                <span>{item.icon}</span> {item.text}
              </p>
            ))}
          </div>

          {/* Social */}
          <div>
            <h5 style={{ marginBottom: 20, fontWeight: 600, fontSize: 16 }}>Follow Us</h5>
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              {[
                { label: "f", title: "Facebook" },
                { label: "in", title: "Instagram" },
                { label: "▶", title: "YouTube" },
                { label: "W", title: "WhatsApp" },
              ].map((s) => (
                <a
                  key={s.title}
                  href="#"
                  title={s.title}
                  style={{
                    width: 42, height: 42, border: "1px solid rgba(255,255,255,0.3)", borderRadius: "50%",
                    display: "inline-flex", alignItems: "center", justifyContent: "center",
                    color: "#fff", textDecoration: "none", fontSize: 14, transition: "0.3s",
                  }}
                  onMouseEnter={(e) => {
                    const el = e.currentTarget;
                    el.style.background = "#FEA116";
                    el.style.borderColor = "#FEA116";
                  }}
                  onMouseLeave={(e) => {
                    const el = e.currentTarget;
                    el.style.background = "transparent";
                    el.style.borderColor = "rgba(255,255,255,0.3)";
                  }}
                >
                  {s.label}
                </a>
              ))}
            </div>
          </div>
        </div>

        <div style={{ borderTop: "1px solid rgba(255,255,255,0.1)", marginTop: 50, padding: "20px 0", textAlign: "center", color: "#aaa", fontSize: 14 }}>
          © 2026 Beef With Chef Melbin. All Rights Reserved.
        </div>
      </div>
    </footer>
  );
}
