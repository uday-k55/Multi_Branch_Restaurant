import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const BG = "https://images.unsplash.com/photo-1535850452425-140ee4a8dbae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwZm9vZCUyMGhlcm8lMjBkYXJrJTIwYW1iaWFuY2V8ZW58MXx8fHwxNzg0NTY4NzIxfDA&ixlib=rb-4.1.0&q=80&w=1080";

export default function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "", remember: false });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showPw, setShowPw] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const err: Record<string, string> = {};
    if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) err.email = "Valid email required";
    if (!form.password || form.password.length < 6) err.password = "Password must be at least 6 characters";
    if (Object.keys(err).length > 0) { setErrors(err); return; }
    if (form.email === "admin@gmail.com" && form.password === "admin@") {
      navigate("/admin");
      return;
    }
    setErrors({ password: "Invalid email or password" });
  };

  const inputStyle = (field: string): React.CSSProperties => ({
    width: "100%", height: 52, padding: "0 16px", border: `1px solid ${errors[field] ? "#ef4444" : "#e2e8f0"}`,
    borderRadius: 10, fontSize: 15, outline: "none", fontFamily: "Poppins, sans-serif",
  });

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <section style={{
        flex: 1, display: "flex", alignItems: "center",
        background: `linear-gradient(rgba(15,23,43,0.90), rgba(15,23,43,0.90)), url("${BG}")`,
        backgroundSize: "cover", backgroundPosition: "center", padding: "100px 24px 60px",
      }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", width: "100%", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center" }} className="auth-grid">
          {/* Left */}
          <div style={{ color: "#fff" }}>
            <h1 style={{ fontSize: "clamp(32px,5vw,55px)", fontWeight: 700, marginBottom: 20, lineHeight: 1.15 }}>
              Welcome Back!
            </h1>
            <p style={{ fontSize: 18, color: "#ddd", marginBottom: 40, lineHeight: 1.7, maxWidth: 400 }}>
              Sign in to continue ordering delicious food from your favourite restaurant branch.
            </p>
            <div style={{ display: "flex", gap: 32, marginBottom: 40 }}>
              {[["🍔", "200+ Dishes"], ["⭐", "4.9 Rating"], ["🚀", "30 min Delivery"]].map(([icon, label]) => (
                <div key={String(label)} style={{ textAlign: "center" }}>
                  <div style={{ fontSize: 28, marginBottom: 6 }}>{icon}</div>
                  <p style={{ color: "#FEA116", fontWeight: 600, fontSize: 14 }}>{label}</p>
                </div>
              ))}
            </div>
            <div style={{ borderRadius: 16, overflow: "hidden", maxWidth: 420 }}>
              <img
                src="https://images.unsplash.com/photo-1763343146204-50aec9ab91ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVhayUyMGJlZWYlMjBjb29raW5nJTIwcmVzdGF1cmFudCUyMGtpdGNoZW58ZW58MXx8fHwxNzg0NTY4NzI2fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Signature dish"
                style={{ width: "100%", height: 240, objectFit: "cover", display: "block", animation: "floatUp 4s ease-in-out infinite" }}
              />
            </div>
          </div>

          {/* Card */}
          <div style={{ background: "#fff", borderRadius: 20, padding: "44px", boxShadow: "0 30px 80px rgba(0,0,0,0.3)" }}>
            <div style={{ textAlign: "center", marginBottom: 32 }}>
              <div style={{ width: 72, height: 72, background: "rgba(254,161,22,0.1)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", fontSize: 34 }}>
                👤
              </div>
              <h2 style={{ fontWeight: 700, fontSize: 26, marginBottom: 6 }}>Login</h2>
              <p style={{ color: "#888", fontSize: 15 }}>Access your account</p>
            </div>

            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: 20 }}>
                <label style={{ display: "block", fontWeight: 600, marginBottom: 8, fontSize: 14 }}>Email Address</label>
                <div style={{ position: "relative" }}>
                  <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", fontSize: 16 }}>✉️</span>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => { setForm((f) => ({ ...f, email: e.target.value })); setErrors((err) => ({ ...err, email: "" })); }}
                    placeholder="Enter your email"
                    style={{ ...inputStyle("email"), paddingLeft: 42 }}
                    onFocus={(e) => { e.target.style.borderColor = "#FEA116"; }}
                    onBlur={(e) => { e.target.style.borderColor = errors.email ? "#ef4444" : "#e2e8f0"; }}
                  />
                </div>
                {errors.email && <p style={{ color: "#ef4444", fontSize: 12, marginTop: 4 }}>{errors.email}</p>}
              </div>

              <div style={{ marginBottom: 20 }}>
                <label style={{ display: "block", fontWeight: 600, marginBottom: 8, fontSize: 14 }}>Password</label>
                <div style={{ position: "relative" }}>
                  <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", fontSize: 16 }}>🔒</span>
                  <input
                    type={showPw ? "text" : "password"}
                    value={form.password}
                    onChange={(e) => { setForm((f) => ({ ...f, password: e.target.value })); setErrors((err) => ({ ...err, password: "" })); }}
                    placeholder="Enter your password"
                    style={{ ...inputStyle("password"), paddingLeft: 42, paddingRight: 42 }}
                    onFocus={(e) => { e.target.style.borderColor = "#FEA116"; }}
                    onBlur={(e) => { e.target.style.borderColor = errors.password ? "#ef4444" : "#e2e8f0"; }}
                  />
                  <button type="button" onClick={() => setShowPw(!showPw)} style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", fontSize: 16 }}>
                    {showPw ? "🙈" : "👁️"}
                  </button>
                </div>
                {errors.password && <p style={{ color: "#ef4444", fontSize: 12, marginTop: 4 }}>{errors.password}</p>}
              </div>

              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 28 }}>
                <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 14 }}>
                  <input
                    type="checkbox"
                    checked={form.remember}
                    onChange={(e) => setForm((f) => ({ ...f, remember: e.target.checked }))}
                    style={{ accentColor: "#FEA116" }}
                  />
                  Remember Me
                </label>
                <a href="#" style={{ color: "#FEA116", textDecoration: "none", fontWeight: 600, fontSize: 14 }}>
                  Forgot Password?
                </a>
              </div>

              <button
                type="submit"
                style={{ width: "100%", padding: "15px", background: "#FEA116", color: "#fff", border: "none", borderRadius: 10, fontWeight: 700, fontSize: 16, cursor: "pointer", transition: "background 0.3s", fontFamily: "Poppins, sans-serif" }}
                onMouseEnter={(e) => { (e.target as HTMLElement).style.background = "#e08a00"; }}
                onMouseLeave={(e) => { (e.target as HTMLElement).style.background = "#FEA116"; }}
              >
                Login
              </button>
            </form>

            <hr style={{ margin: "24px 0", borderColor: "#f0f0f0" }} />
            <p style={{ textAlign: "center", margin: 0, fontSize: 15, color: "#555" }}>
              Don't have an account?{" "}
              <Link to="/register" style={{ color: "#FEA116", textDecoration: "none", fontWeight: 600 }}>
                Register Now
              </Link>
            </p>
          </div>
        </div>
      </section>

      <style>{`
        @keyframes floatUp {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-14px); }
        }
        @media (max-width: 768px) {
          .auth-grid { grid-template-columns: 1fr !important; }
          .auth-grid > div:first-child { display: none; }
        }
      `}</style>
    </div>
  );
}
