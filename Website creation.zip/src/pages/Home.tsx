import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Footer from "../components/Footer";

const HERO_BG = "https://images.unsplash.com/photo-1535850452425-140ee4a8dbae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwZm9vZCUyMGhlcm8lMjBkYXJrJTIwYW1iaWFuY2V8ZW58MXx8fHwxNzg0NTY4NzIxfDA&ixlib=rb-4.1.0&q=80&w=1080";
const FAQ_BG = "https://images.unsplash.com/photo-1552566626-52f8b828add9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwaW50ZXJpb3J8ZW58MXx8fHwxNzg0NTY4NzIxfDA&ixlib=rb-4.1.0&q=80&w=1080";

const CAROUSEL_SLIDES = [
  {
    img: "https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXJnZXIlMjBnb3VybWV0JTIwZm9vZCUyMGRlYWwlMjBvZmZlcnxlbnwxfHx8fDE3ODQ1Njg3MjJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "20% OFF On Burgers",
    sub: "Available only today",
    cta: "Order Now",
  },
  {
    img: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXp6YSUyMG1hcmdoZXJpdGElMjBpdGFsaWFufGVufDF8fHx8MTc4NDU2ODcyNXww&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Buy 1 Get 1 Pizza",
    sub: "Weekend Special",
    cta: "Explore",
  },
  {
    img: "https://images.unsplash.com/photo-1550547660-d9450f859349?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxidXJnZXIlMjBnb3VybWV0JTIwZm9vZCUyMGRlYWwlMjBvZmZlcnxlbnwxfHx8fDE3ODQ1Njg3MjJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Free Delivery",
    sub: "Orders Above ₹499",
    cta: "Shop Now",
  },
];

const SERVICES = [
  {
    icon: (
      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#FEA116" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /><polyline points="9 22 9 12 15 12 15 22" />
      </svg>
    ),
    title: "Dine In",
    desc: "Reserve or scan the QR code on your table and place orders instantly.",
  },
  {
    icon: (
      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#FEA116" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" /><path d="M8.56 2.75c4.37 6.03 6.02 9.42 8.03 17.72m2.54-15.38c-3.72 4.35-8.94 5.66-16.88 5.85m19.5 1.9c-3.5-.93-6.63-.82-8.94 0-2.58.92-5.01 2.86-7.44 6.32" />
      </svg>
    ),
    title: "Home Delivery",
    desc: "Fast delivery from your nearest restaurant branch.",
  },
  {
    icon: (
      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#FEA116" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" /><line x1="3" y1="6" x2="21" y2="6" /><path d="M16 10a4 4 0 0 1-8 0" />
      </svg>
    ),
    title: "Take Away",
    desc: "Order online and collect your food without waiting.",
  },
  {
    icon: (
      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#FEA116" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2" /><path d="M7 7h2v2H7zm0 8h2v2H7zm8-8h2v2h-2zm0 8h2v2h-2zM7 11h2v2H7zm4-4h2v2h-2zm0 8h2v2h-2zm4-4h2v2h-2zm-4 0h2v2h-2z" />
      </svg>
    ),
    title: "QR Ordering",
    desc: "Scan the QR code at your table and order without calling staff.",
  },
];

const FAQS = [
  {
    q: "How does QR Ordering work?",
    a: "Scan the QR code placed on your restaurant table and start ordering instantly without waiting for staff.",
  },
  {
    q: "Can I order home delivery?",
    a: "Yes. Select your nearest branch, add items to your cart, and place your order for home delivery.",
  },
  {
    q: "Can I choose Takeaway?",
    a: "Yes. Place the order online and collect it from the selected branch at your preferred time.",
  },
  {
    q: "Are there any delivery charges?",
    a: "Free delivery on orders above ₹499. Standard delivery charges apply for smaller orders.",
  },
];

function ServiceCard({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered ? "#FEA116" : "#fff",
        padding: "40px 28px",
        textAlign: "center",
        borderRadius: 16,
        boxShadow: "0 10px 30px rgba(0,0,0,0.08)",
        transition: "all 0.35s",
        transform: hovered ? "translateY(-10px)" : "none",
        cursor: "default",
        height: "100%",
      }}
    >
      <div style={{ marginBottom: 20, filter: hovered ? "brightness(10)" : "none", transition: "0.3s" }}>
        {icon}
      </div>
      <h4 style={{ fontWeight: 600, marginBottom: 12, color: hovered ? "#fff" : "#1a1a1a", fontSize: 18 }}>{title}</h4>
      <p style={{ color: hovered ? "rgba(255,255,255,0.9)" : "#6c757d", fontSize: 15, lineHeight: 1.65 }}>{desc}</p>
    </div>
  );
}

export default function Home() {
  const [slide, setSlide] = useState(0);
  const [openFaq, setOpenFaq] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setSlide((s) => (s + 1) % CAROUSEL_SLIDES.length), 5000);
    return () => clearInterval(t);
  }, []);

  return (
    <div>
      {/* HERO */}
      <section
        style={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          background: `linear-gradient(rgba(15,23,43,0.88), rgba(15,23,43,0.88)), url("${HERO_BG}")`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          color: "#fff",
          paddingTop: 90,
        }}
      >
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "60px 24px", width: "100%" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center" }} className="hero-grid">
            <div>
              <p style={{ color: "#FEA116", fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", marginBottom: 16, fontSize: 14 }}>
                Multi Branch Restaurant System
              </p>
              <h1 style={{ fontSize: "clamp(36px,5vw,60px)", fontWeight: 700, lineHeight: 1.15, marginBottom: 24 }}>
                Order Delicious Food<br />
                From Your Favourite<br />
                <span style={{ color: "#FEA116" }}>Restaurant Branch</span>
              </h1>
              <p style={{ fontSize: 18, color: "#ddd", lineHeight: 1.7, marginBottom: 40, maxWidth: 480 }}>
                Enjoy Dine-In, Home Delivery, Takeaway and QR Table Ordering from multiple restaurant branches with one easy platform.
              </p>
              <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
                <Link
                  to="/login"
                  style={{
                    background: "#FEA116", color: "#fff", textDecoration: "none",
                    padding: "14px 32px", borderRadius: 8, fontWeight: 600, fontSize: 16,
                    transition: "background 0.3s",
                  }}
                  onMouseEnter={(e) => { (e.target as HTMLElement).style.background = "#e08a00"; }}
                  onMouseLeave={(e) => { (e.target as HTMLElement).style.background = "#FEA116"; }}
                >
                  Order Now
                </Link>
                <a
                  href="#services"
                  style={{
                    border: "2px solid #fff", color: "#fff", textDecoration: "none",
                    padding: "14px 32px", borderRadius: 8, fontWeight: 600, fontSize: 16,
                    transition: "all 0.3s",
                  }}
                  onMouseEnter={(e) => { const el = e.currentTarget; el.style.background = "#fff"; el.style.color = "#0F172B"; }}
                  onMouseLeave={(e) => { const el = e.currentTarget; el.style.background = "transparent"; el.style.color = "#fff"; }}
                >
                  Explore Menu
                </a>
              </div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{
                width: 340, height: 340, borderRadius: "50%", background: "rgba(254,161,22,0.12)",
                border: "3px solid rgba(254,161,22,0.3)", display: "flex", alignItems: "center", justifyContent: "center",
                margin: "0 auto", animation: "slowSpin 35s linear infinite",
              }}>
                <div style={{ width: 280, height: 280, borderRadius: "50%", overflow: "hidden", border: "4px solid rgba(254,161,22,0.5)" }}>
                  <img
                    src="https://images.unsplash.com/photo-1763343146204-50aec9ab91ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVhayUyMGJlZWYlMjBjb29raW5nJTIwcmVzdGF1cmFudCUyMGtpdGNoZW58ZW58MXx8fHwxNzg0NTY4NzI2fDA&ixlib=rb-4.1.0&q=80&w=1080"
                    alt="Signature dish"
                    style={{ width: "100%", height: "100%", objectFit: "cover" }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" style={{ padding: "90px 0", background: "#f8f9fa" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
          <div style={{ textAlign: "center", marginBottom: 60 }}>
            <p style={{ color: "#FEA116", fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", fontSize: 14, marginBottom: 12 }}>
              OUR SERVICES
            </p>
            <h2 style={{ fontSize: "clamp(28px,4vw,42px)", fontWeight: 700, color: "#0F172B" }}>Everything You Need</h2>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 28 }}>
            {SERVICES.map((s) => (
              <ServiceCard key={s.title} {...s} />
            ))}
          </div>
        </div>
      </section>

      {/* SPECIAL OFFERS CAROUSEL */}
      <section style={{ padding: "90px 0", background: "#fff" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
          <div style={{ textAlign: "center", marginBottom: 60 }}>
            <p style={{ color: "#FEA116", fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", fontSize: 14, marginBottom: 12 }}>
              SPECIAL OFFERS
            </p>
            <h2 style={{ fontSize: "clamp(28px,4vw,42px)", fontWeight: 700, color: "#0F172B" }}>Today's Best Deals</h2>
          </div>
          <div style={{ position: "relative", borderRadius: 16, overflow: "hidden", boxShadow: "0 20px 60px rgba(0,0,0,0.15)" }}>
            {CAROUSEL_SLIDES.map((s, i) => (
              <div
                key={i}
                style={{
                  display: i === slide ? "block" : "none",
                  position: "relative",
                }}
              >
                <img
                  src={s.img}
                  alt={s.title}
                  style={{ width: "100%", height: 500, objectFit: "cover", display: "block" }}
                />
                <div style={{
                  position: "absolute", inset: 0,
                  background: "linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.2) 60%, transparent 100%)",
                  display: "flex", alignItems: "flex-end", padding: "0 60px 60px",
                }}>
                  <div style={{ background: "rgba(0,0,0,0.55)", borderRadius: 12, padding: "24px 32px", maxWidth: 400 }}>
                    <h2 style={{ color: "#fff", fontWeight: 700, fontSize: 28, marginBottom: 8 }}>{s.title}</h2>
                    <p style={{ color: "#ddd", marginBottom: 18, fontSize: 16 }}>{s.sub}</p>
                    <Link
                      to="/login"
                      style={{ background: "#FEA116", color: "#fff", textDecoration: "none", padding: "10px 24px", borderRadius: 8, fontWeight: 600, fontSize: 15 }}
                    >
                      {s.cta}
                    </Link>
                  </div>
                </div>
              </div>
            ))}
            {/* Controls */}
            {[[-1, "❮", "left"], [1, "❯", "right"]].map(([dir, ch, side]) => (
              <button
                key={String(side)}
                onClick={() => setSlide((s) => (s + Number(dir) + CAROUSEL_SLIDES.length) % CAROUSEL_SLIDES.length)}
                style={{
                  position: "absolute", top: "50%", [String(side)]: 20, transform: "translateY(-50%)",
                  background: "rgba(0,0,0,0.5)", color: "#fff", border: "none", width: 44, height: 44,
                  borderRadius: "50%", fontSize: 18, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
                  transition: "background 0.3s",
                }}
                onMouseEnter={(e) => { (e.target as HTMLElement).style.background = "#FEA116"; }}
                onMouseLeave={(e) => { (e.target as HTMLElement).style.background = "rgba(0,0,0,0.5)"; }}
              >
                {ch}
              </button>
            ))}
            {/* Dots */}
            <div style={{ position: "absolute", bottom: 20, left: "50%", transform: "translateX(-50%)", display: "flex", gap: 8 }}>
              {CAROUSEL_SLIDES.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setSlide(i)}
                  style={{
                    width: i === slide ? 24 : 8, height: 8, borderRadius: 4, border: "none",
                    background: i === slide ? "#FEA116" : "rgba(255,255,255,0.5)", cursor: "pointer", transition: "all 0.3s",
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ / WHY CHOOSE US */}
      <section style={{ padding: "90px 0", background: "#f8f9fa" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center" }} className="faq-grid">
            <div style={{ borderRadius: 16, overflow: "hidden", boxShadow: "0 20px 50px rgba(0,0,0,0.12)" }}>
              <img
                src={FAQ_BG}
                alt="Restaurant interior"
                style={{ width: "100%", height: 500, objectFit: "cover", display: "block" }}
              />
            </div>
            <div>
              <p style={{ color: "#FEA116", fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", fontSize: 14, marginBottom: 12 }}>
                WHY CHOOSE US
              </p>
              <h2 style={{ fontSize: "clamp(26px,3.5vw,38px)", fontWeight: 700, color: "#0F172B", marginBottom: 32 }}>
                Frequently Asked Questions
              </h2>
              <div>
                {FAQS.map((faq, i) => (
                  <div
                    key={i}
                    style={{
                      marginBottom: 12, borderRadius: 10, overflow: "hidden",
                      border: "1px solid #e2e8f0", background: "#fff",
                      boxShadow: openFaq === i ? "0 4px 15px rgba(254,161,22,0.15)" : "none",
                    }}
                  >
                    <button
                      onClick={() => setOpenFaq(openFaq === i ? -1 : i)}
                      style={{
                        width: "100%", textAlign: "left", padding: "18px 20px",
                        background: openFaq === i ? "#FEA116" : "#fff", border: "none", cursor: "pointer",
                        fontWeight: 600, fontSize: 15, color: openFaq === i ? "#fff" : "#1a1a1a",
                        display: "flex", justifyContent: "space-between", alignItems: "center", transition: "all 0.3s",
                        fontFamily: "Poppins, sans-serif",
                      }}
                    >
                      {faq.q}
                      <span style={{ fontSize: 18, transition: "transform 0.3s", transform: openFaq === i ? "rotate(180deg)" : "none" }}>
                        ▼
                      </span>
                    </button>
                    {openFaq === i && (
                      <div style={{ padding: "16px 20px", color: "#555", fontSize: 15, lineHeight: 1.65 }}>
                        {faq.a}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA BANNER */}
      <section style={{
        padding: "80px 24px", textAlign: "center",
        background: `linear-gradient(rgba(15,23,43,0.92), rgba(15,23,43,0.92)), url("https://images.unsplash.com/photo-1583354608715-177553a4035e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxyZXN0YXVyYW50JTIwZm9vZCUyMGhlcm8lMjBkYXJrJTIwYW1iaWFuY2V8ZW58MXx8fHwxNzg0NTY4NzIxfDA&ixlib=rb-4.1.0&q=80&w=1080")`,
        backgroundSize: "cover", backgroundPosition: "center",
      }}>
        <h2 style={{ color: "#fff", fontSize: "clamp(26px,4vw,42px)", fontWeight: 700, marginBottom: 16 }}>
          Ready to Experience the Best Food?
        </h2>
        <p style={{ color: "#ddd", fontSize: 18, marginBottom: 36, maxWidth: 500, margin: "0 auto 36px" }}>
          Join thousands of happy customers ordering from Chef Melbin's kitchen every day.
        </p>
        <Link
          to="/register"
          style={{
            background: "#FEA116", color: "#fff", textDecoration: "none",
            padding: "16px 40px", borderRadius: 8, fontWeight: 700, fontSize: 17, display: "inline-block",
            transition: "background 0.3s",
          }}
          onMouseEnter={(e) => { (e.target as HTMLElement).style.background = "#e08a00"; }}
          onMouseLeave={(e) => { (e.target as HTMLElement).style.background = "#FEA116"; }}
        >
          Get Started Free
        </Link>
      </section>

      <Footer />

      <style>{`
        @keyframes slowSpin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @media (max-width: 768px) {
          .hero-grid { grid-template-columns: 1fr !important; text-align: center; }
          .hero-grid > div:last-child { display: none; }
          .faq-grid { grid-template-columns: 1fr !important; }
          .faq-grid > div:first-child { display: none; }
        }
      `}</style>
    </div>
  );
}
