import { useState } from "react";
import { useNavigate } from "react-router-dom";

// ── Types ──────────────────────────────────────────────────────────────────────
interface Branch {
  id: number;
  name: string;
  location: string;
  phone: string;
  status: "Active" | "Inactive";
}

interface MenuItem {
  id: number;
  name: string;
  category: string;
  price: number;
  branch: string;
  status: "Available" | "Unavailable";
}

interface Order {
  id: string;
  customer: string;
  branch: string;
  items: string;
  amount: number;
  type: "Dine In" | "Delivery" | "Takeaway";
  status: "Pending" | "Preparing" | "Delivered" | "Cancelled";
  date: string;
}

interface Staff {
  id: number;
  name: string;
  role: string;
  branch: string;
  phone: string;
  status: "Active" | "Off Duty";
}

// ── Seed data ──────────────────────────────────────────────────────────────────
const initBranches: Branch[] = [
  { id: 1, name: "Kottayam Main", location: "Baker Junction, Kottayam", phone: "+91 9876543210", status: "Active" },
  { id: 2, name: "Ernakulam Branch", location: "MG Road, Ernakulam", phone: "+91 9876543211", status: "Active" },
  { id: 3, name: "Trivandrum Branch", location: "Kazhakuttom, Trivandrum", phone: "+91 9876543212", status: "Inactive" },
];

const initMenuItems: MenuItem[] = [
  { id: 1, name: "Beef Fry", category: "Starters", price: 180, branch: "Kottayam Main", status: "Available" },
  { id: 2, name: "Kerala Beef Curry", category: "Main Course", price: 220, branch: "Kottayam Main", status: "Available" },
  { id: 3, name: "Beef Biriyani", category: "Rice", price: 280, branch: "Ernakulam Branch", status: "Available" },
  { id: 4, name: "Beef Burger", category: "Burgers", price: 160, branch: "Ernakulam Branch", status: "Unavailable" },
  { id: 5, name: "Mutton Roast", category: "Main Course", price: 260, branch: "Trivandrum Branch", status: "Available" },
];

const initOrders: Order[] = [
  { id: "#1042", customer: "Rajan Nair", branch: "Kottayam Main", items: "Beef Fry, Beef Curry", amount: 400, type: "Dine In", status: "Delivered", date: "2026-07-21" },
  { id: "#1043", customer: "Anitha Joseph", branch: "Ernakulam Branch", items: "Beef Biriyani x2", amount: 560, type: "Delivery", status: "Preparing", date: "2026-07-21" },
  { id: "#1044", customer: "Suresh Kumar", branch: "Kottayam Main", items: "Beef Burger, Fries", amount: 240, type: "Takeaway", status: "Pending", date: "2026-07-21" },
  { id: "#1045", customer: "Meera Das", branch: "Trivandrum Branch", items: "Mutton Roast, Rice", amount: 380, type: "Dine In", status: "Cancelled", date: "2026-07-20" },
  { id: "#1046", customer: "Thomas Varghese", branch: "Ernakulam Branch", items: "Beef Fry, Beef Curry", amount: 400, type: "Delivery", status: "Delivered", date: "2026-07-20" },
];

const initStaff: Staff[] = [
  { id: 1, name: "Chef Melbin", role: "Head Chef", branch: "Kottayam Main", phone: "+91 9876540001", status: "Active" },
  { id: 2, name: "Alex John", role: "Grill Chef", branch: "Kottayam Main", phone: "+91 9876540002", status: "Active" },
  { id: 3, name: "Sarah George", role: "Pastry Chef", branch: "Ernakulam Branch", phone: "+91 9876540003", status: "Active" },
  { id: 4, name: "Mathew Jose", role: "Kitchen Manager", branch: "Trivandrum Branch", phone: "+91 9876540004", status: "Off Duty" },
  { id: 5, name: "Priya Nair", role: "Cashier", branch: "Kottayam Main", phone: "+91 9876540005", status: "Active" },
];

// ── Palette & helpers ──────────────────────────────────────────────────────────
const P = "#FEA116";
const DARK = "#0F172B";

function Badge({ label, color }: { label: string; color: string }) {
  const map: Record<string, [string, string]> = {
    Active: ["#d1fae5", "#065f46"],
    "Off Duty": ["#fee2e2", "#991b1b"],
    Inactive: ["#f3f4f6", "#374151"],
    Available: ["#d1fae5", "#065f46"],
    Unavailable: ["#fee2e2", "#991b1b"],
    Delivered: ["#d1fae5", "#065f46"],
    Preparing: ["#fef3c7", "#92400e"],
    Pending: ["#dbeafe", "#1e40af"],
    Cancelled: ["#fee2e2", "#991b1b"],
    "Dine In": ["#ede9fe", "#5b21b6"],
    Delivery: ["#dbeafe", "#1e40af"],
    Takeaway: ["#fce7f3", "#9d174d"],
  };
  const [bg, fg] = map[label] ?? ["#f3f4f6", "#374151"];
  return (
    <span style={{ background: bg, color: fg, borderRadius: 20, padding: "3px 12px", fontSize: 12, fontWeight: 600 }}>
      {label}
    </span>
  );
}

function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{ background: "#fff", borderRadius: 14, padding: "24px", boxShadow: "0 2px 12px rgba(0,0,0,0.06)", ...style }}>
      {children}
    </div>
  );
}

function SectionHeader({ title, onAdd, addLabel }: { title: string; onAdd?: () => void; addLabel?: string }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
      <h2 style={{ fontWeight: 700, fontSize: 20, color: DARK, margin: 0 }}>{title}</h2>
      {onAdd && (
        <button
          onClick={onAdd}
          style={{ background: P, color: "#fff", border: "none", borderRadius: 8, padding: "9px 20px", fontWeight: 600, fontSize: 14, cursor: "pointer", display: "flex", alignItems: "center", gap: 6, fontFamily: "Poppins, sans-serif" }}
        >
          + {addLabel}
        </button>
      )}
    </div>
  );
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <div style={{ background: "#fff", borderRadius: 16, padding: "32px", width: "100%", maxWidth: 480, boxShadow: "0 30px 80px rgba(0,0,0,0.25)", animation: "popIn 0.2s ease-out" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
          <h3 style={{ margin: 0, fontWeight: 700, fontSize: 18, color: DARK }}>{title}</h3>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: "#888", lineHeight: 1 }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Input({ label, value, onChange, type = "text", required }: { label: string; value: string; onChange: (v: string) => void; type?: string; required?: boolean }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{ display: "block", fontWeight: 600, fontSize: 13, marginBottom: 6, color: "#374151" }}>{label}{required && " *"}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        style={{ width: "100%", height: 44, padding: "0 14px", border: "1px solid #e2e8f0", borderRadius: 8, fontSize: 14, outline: "none", fontFamily: "Poppins, sans-serif" }}
        onFocus={(e) => { e.target.style.borderColor = P; }}
        onBlur={(e) => { e.target.style.borderColor = "#e2e8f0"; }}
      />
    </div>
  );
}

function Select({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{ display: "block", fontWeight: 600, fontSize: 13, marginBottom: 6, color: "#374151" }}>{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{ width: "100%", height: 44, padding: "0 14px", border: "1px solid #e2e8f0", borderRadius: 8, fontSize: 14, outline: "none", background: "#fff", fontFamily: "Poppins, sans-serif" }}
        onFocus={(e) => { e.target.style.borderColor = P; }}
        onBlur={(e) => { e.target.style.borderColor = "#e2e8f0"; }}
      >
        {options.map((o) => <option key={o}>{o}</option>)}
      </select>
    </div>
  );
}

// ── Sections ───────────────────────────────────────────────────────────────────
function BranchesSection({ branches, setBranches }: { branches: Branch[]; setBranches: React.Dispatch<React.SetStateAction<Branch[]>> }) {
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: "", location: "", phone: "", status: "Active" as Branch["status"] });

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    setBranches((prev) => [...prev, { id: Date.now(), ...form }]);
    setShowModal(false);
    setForm({ name: "", location: "", phone: "", status: "Active" });
  };

  const toggle = (id: number) => {
    setBranches((prev) => prev.map((b) => b.id === id ? { ...b, status: b.status === "Active" ? "Inactive" : "Active" } : b));
  };

  return (
    <>
      <SectionHeader title="Branches" onAdd={() => setShowModal(true)} addLabel="Add Branch" />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 18 }}>
        {branches.map((b) => (
          <Card key={b.id}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <div style={{ width: 44, height: 44, background: "rgba(254,161,22,0.1)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>🏪</div>
              <Badge label={b.status} color={b.status === "Active" ? "green" : "gray"} />
            </div>
            <h4 style={{ fontWeight: 700, marginBottom: 6, color: DARK }}>{b.name}</h4>
            <p style={{ color: "#666", fontSize: 13, marginBottom: 4 }}>📍 {b.location}</p>
            <p style={{ color: "#666", fontSize: 13, marginBottom: 16 }}>📞 {b.phone}</p>
            <button
              onClick={() => toggle(b.id)}
              style={{ background: b.status === "Active" ? "#fee2e2" : "#d1fae5", color: b.status === "Active" ? "#991b1b" : "#065f46", border: "none", borderRadius: 7, padding: "7px 14px", fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "Poppins, sans-serif" }}
            >
              {b.status === "Active" ? "Deactivate" : "Activate"}
            </button>
          </Card>
        ))}
      </div>

      {showModal && (
        <Modal title="Add New Branch" onClose={() => setShowModal(false)}>
          <form onSubmit={handleAdd}>
            <Input label="Branch Name" value={form.name} onChange={(v) => setForm((f) => ({ ...f, name: v }))} required />
            <Input label="Location" value={form.location} onChange={(v) => setForm((f) => ({ ...f, location: v }))} required />
            <Input label="Phone" value={form.phone} onChange={(v) => setForm((f) => ({ ...f, phone: v }))} required />
            <Select label="Status" value={form.status} onChange={(v) => setForm((f) => ({ ...f, status: v as Branch["status"] }))} options={["Active", "Inactive"]} />
            <button type="submit" style={{ width: "100%", padding: "13px", background: P, color: "#fff", border: "none", borderRadius: 10, fontWeight: 700, fontSize: 15, cursor: "pointer", marginTop: 4, fontFamily: "Poppins, sans-serif" }}>
              Add Branch
            </button>
          </form>
        </Modal>
      )}
    </>
  );
}

function MenuSection({ menu, setMenu, branches }: { menu: MenuItem[]; setMenu: React.Dispatch<React.SetStateAction<MenuItem[]>>; branches: Branch[] }) {
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: "", category: "Starters", price: "", branch: branches[0]?.name ?? "", status: "Available" as MenuItem["status"] });
  const [filter, setFilter] = useState("All");

  const categories = ["All", "Starters", "Main Course", "Rice", "Burgers", "Desserts", "Beverages"];
  const filtered = filter === "All" ? menu : menu.filter((m) => m.category === filter);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    setMenu((prev) => [...prev, { id: Date.now(), name: form.name, category: form.category, price: Number(form.price), branch: form.branch, status: form.status }]);
    setShowModal(false);
    setForm({ name: "", category: "Starters", price: "", branch: branches[0]?.name ?? "", status: "Available" });
  };

  const toggleStatus = (id: number) => {
    setMenu((prev) => prev.map((m) => m.id === id ? { ...m, status: m.status === "Available" ? "Unavailable" : "Available" } : m));
  };

  const remove = (id: number) => setMenu((prev) => prev.filter((m) => m.id !== id));

  return (
    <>
      <SectionHeader title="Menu Items" onAdd={() => setShowModal(true)} addLabel="Add Item" />
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 20 }}>
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setFilter(c)}
            style={{ padding: "6px 16px", borderRadius: 20, border: "none", background: filter === c ? P : "#f3f4f6", color: filter === c ? "#fff" : "#555", fontWeight: 600, fontSize: 13, cursor: "pointer", fontFamily: "Poppins, sans-serif" }}
          >
            {c}
          </button>
        ))}
      </div>
      <Card style={{ padding: 0, overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#f8fafc", borderBottom: "1px solid #e2e8f0" }}>
              {["Item", "Category", "Price", "Branch", "Status", "Actions"].map((h) => (
                <th key={h} style={{ padding: "13px 16px", textAlign: "left", fontSize: 13, fontWeight: 600, color: "#64748b", whiteSpace: "nowrap" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((m, i) => (
              <tr key={m.id} style={{ borderBottom: "1px solid #f1f5f9", background: i % 2 === 0 ? "#fff" : "#fafafa" }}>
                <td style={{ padding: "13px 16px", fontWeight: 600, fontSize: 14 }}>{m.name}</td>
                <td style={{ padding: "13px 16px", fontSize: 13, color: "#555" }}>{m.category}</td>
                <td style={{ padding: "13px 16px", fontWeight: 700, color: P }}>₹{m.price}</td>
                <td style={{ padding: "13px 16px", fontSize: 13, color: "#555" }}>{m.branch}</td>
                <td style={{ padding: "13px 16px" }}><Badge label={m.status} color="" /></td>
                <td style={{ padding: "13px 16px" }}>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button onClick={() => toggleStatus(m.id)} style={{ background: "#f3f4f6", border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, cursor: "pointer", fontFamily: "Poppins, sans-serif", fontWeight: 600 }}>
                      {m.status === "Available" ? "Disable" : "Enable"}
                    </button>
                    <button onClick={() => remove(m.id)} style={{ background: "#fee2e2", color: "#991b1b", border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, cursor: "pointer", fontFamily: "Poppins, sans-serif", fontWeight: 600 }}>
                      Remove
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={6} style={{ padding: 40, textAlign: "center", color: "#aaa" }}>No items in this category</td></tr>
            )}
          </tbody>
        </table>
      </Card>

      {showModal && (
        <Modal title="Add Menu Item" onClose={() => setShowModal(false)}>
          <form onSubmit={handleAdd}>
            <Input label="Item Name" value={form.name} onChange={(v) => setForm((f) => ({ ...f, name: v }))} required />
            <Select label="Category" value={form.category} onChange={(v) => setForm((f) => ({ ...f, category: v }))} options={["Starters", "Main Course", "Rice", "Burgers", "Desserts", "Beverages"]} />
            <Input label="Price (₹)" value={form.price} onChange={(v) => setForm((f) => ({ ...f, price: v }))} type="number" required />
            <Select label="Branch" value={form.branch} onChange={(v) => setForm((f) => ({ ...f, branch: v }))} options={branches.map((b) => b.name)} />
            <Select label="Status" value={form.status} onChange={(v) => setForm((f) => ({ ...f, status: v as MenuItem["status"] }))} options={["Available", "Unavailable"]} />
            <button type="submit" style={{ width: "100%", padding: "13px", background: P, color: "#fff", border: "none", borderRadius: 10, fontWeight: 700, fontSize: 15, cursor: "pointer", marginTop: 4, fontFamily: "Poppins, sans-serif" }}>
              Add Item
            </button>
          </form>
        </Modal>
      )}
    </>
  );
}

function OrdersSection({ orders, setOrders }: { orders: Order[]; setOrders: React.Dispatch<React.SetStateAction<Order[]>> }) {
  const [filter, setFilter] = useState<Order["status"] | "All">("All");
  const filtered = filter === "All" ? orders : orders.filter((o) => o.status === filter);
  const statuses: Array<Order["status"] | "All"> = ["All", "Pending", "Preparing", "Delivered", "Cancelled"];

  const nextStatus: Partial<Record<Order["status"], Order["status"]>> = {
    Pending: "Preparing",
    Preparing: "Delivered",
  };

  const advance = (id: string) => {
    setOrders((prev) => prev.map((o) => {
      if (o.id !== id) return o;
      const next = nextStatus[o.status];
      return next ? { ...o, status: next } : o;
    }));
  };

  return (
    <>
      <SectionHeader title="Orders" />
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 20 }}>
        {statuses.map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            style={{ padding: "6px 16px", borderRadius: 20, border: "none", background: filter === s ? P : "#f3f4f6", color: filter === s ? "#fff" : "#555", fontWeight: 600, fontSize: 13, cursor: "pointer", fontFamily: "Poppins, sans-serif" }}
          >
            {s} {s !== "All" && `(${orders.filter((o) => o.status === s).length})`}
          </button>
        ))}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {filtered.map((o) => (
          <Card key={o.id} style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
            <div style={{ fontWeight: 700, fontSize: 15, color: P, minWidth: 60 }}>{o.id}</div>
            <div style={{ flex: 1, minWidth: 140 }}>
              <p style={{ margin: 0, fontWeight: 600, fontSize: 14 }}>{o.customer}</p>
              <p style={{ margin: 0, fontSize: 12, color: "#888" }}>{o.branch}</p>
            </div>
            <div style={{ flex: 2, minWidth: 160 }}>
              <p style={{ margin: 0, fontSize: 13, color: "#555" }}>{o.items}</p>
            </div>
            <div style={{ fontWeight: 700, fontSize: 15, minWidth: 70 }}>₹{o.amount}</div>
            <Badge label={o.type} color="" />
            <Badge label={o.status} color="" />
            <div style={{ fontSize: 12, color: "#aaa", minWidth: 90 }}>{o.date}</div>
            {nextStatus[o.status] && (
              <button
                onClick={() => advance(o.id)}
                style={{ background: P, color: "#fff", border: "none", borderRadius: 7, padding: "7px 14px", fontSize: 12, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap", fontFamily: "Poppins, sans-serif" }}
              >
                → {nextStatus[o.status]}
              </button>
            )}
          </Card>
        ))}
        {filtered.length === 0 && (
          <Card style={{ textAlign: "center", color: "#aaa", padding: 48 }}>No orders found</Card>
        )}
      </div>
    </>
  );
}

function StaffSection({ staff, setStaff, branches }: { staff: Staff[]; setStaff: React.Dispatch<React.SetStateAction<Staff[]>>; branches: Branch[] }) {
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: "", role: "", branch: branches[0]?.name ?? "", phone: "", status: "Active" as Staff["status"] });

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    setStaff((prev) => [...prev, { id: Date.now(), ...form }]);
    setShowModal(false);
    setForm({ name: "", role: "", branch: branches[0]?.name ?? "", phone: "", status: "Active" });
  };

  const toggle = (id: number) => {
    setStaff((prev) => prev.map((s) => s.id === id ? { ...s, status: s.status === "Active" ? "Off Duty" : "Active" } : s));
  };

  return (
    <>
      <SectionHeader title="Staff" onAdd={() => setShowModal(true)} addLabel="Add Staff" />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(270px, 1fr))", gap: 18 }}>
        {staff.map((s) => (
          <Card key={s.id}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <div style={{ width: 48, height: 48, borderRadius: "50%", background: `hsl(${(s.id * 57) % 360}, 60%, 88%)`, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 18, color: `hsl(${(s.id * 57) % 360}, 50%, 35%)` }}>
                {s.name.charAt(0)}
              </div>
              <Badge label={s.status} color="" />
            </div>
            <h4 style={{ fontWeight: 700, marginBottom: 4, color: DARK }}>{s.name}</h4>
            <p style={{ color: P, fontSize: 13, fontWeight: 600, marginBottom: 8 }}>{s.role}</p>
            <p style={{ color: "#666", fontSize: 13, marginBottom: 3 }}>🏪 {s.branch}</p>
            <p style={{ color: "#666", fontSize: 13, marginBottom: 16 }}>📞 {s.phone}</p>
            <button
              onClick={() => toggle(s.id)}
              style={{ background: s.status === "Active" ? "#fee2e2" : "#d1fae5", color: s.status === "Active" ? "#991b1b" : "#065f46", border: "none", borderRadius: 7, padding: "7px 14px", fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "Poppins, sans-serif" }}
            >
              {s.status === "Active" ? "Mark Off Duty" : "Mark Active"}
            </button>
          </Card>
        ))}
      </div>

      {showModal && (
        <Modal title="Add Staff Member" onClose={() => setShowModal(false)}>
          <form onSubmit={handleAdd}>
            <Input label="Full Name" value={form.name} onChange={(v) => setForm((f) => ({ ...f, name: v }))} required />
            <Input label="Role / Designation" value={form.role} onChange={(v) => setForm((f) => ({ ...f, role: v }))} required />
            <Select label="Branch" value={form.branch} onChange={(v) => setForm((f) => ({ ...f, branch: v }))} options={branches.map((b) => b.name)} />
            <Input label="Phone" value={form.phone} onChange={(v) => setForm((f) => ({ ...f, phone: v }))} required />
            <Select label="Status" value={form.status} onChange={(v) => setForm((f) => ({ ...f, status: v as Staff["status"] }))} options={["Active", "Off Duty"]} />
            <button type="submit" style={{ width: "100%", padding: "13px", background: P, color: "#fff", border: "none", borderRadius: 10, fontWeight: 700, fontSize: 15, cursor: "pointer", marginTop: 4, fontFamily: "Poppins, sans-serif" }}>
              Add Staff
            </button>
          </form>
        </Modal>
      )}
    </>
  );
}

// ── Main Dashboard ─────────────────────────────────────────────────────────────
type Tab = "overview" | "branches" | "menu" | "orders" | "staff";

const NAV_ITEMS: Array<{ id: Tab; label: string; icon: string }> = [
  { id: "overview", label: "Overview", icon: "📊" },
  { id: "branches", label: "Branches", icon: "🏪" },
  { id: "menu", label: "Menu", icon: "🍽️" },
  { id: "orders", label: "Orders", icon: "📦" },
  { id: "staff", label: "Staff", icon: "👨‍🍳" },
];

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("overview");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [branches, setBranches] = useState<Branch[]>(initBranches);
  const [menu, setMenu] = useState<MenuItem[]>(initMenuItems);
  const [orders, setOrders] = useState<Order[]>(initOrders);
  const [staff, setStaff] = useState<Staff[]>(initStaff);

  const stats = [
    { label: "Total Branches", value: branches.length, icon: "🏪", color: "#ede9fe", sub: `${branches.filter((b) => b.status === "Active").length} active` },
    { label: "Menu Items", value: menu.length, icon: "🍽️", color: "#dbeafe", sub: `${menu.filter((m) => m.status === "Available").length} available` },
    { label: "Today's Orders", value: orders.filter((o) => o.date === "2026-07-21").length, icon: "📦", color: "#fef3c7", sub: `₹${orders.filter((o) => o.date === "2026-07-21").reduce((a, o) => a + o.amount, 0)} revenue` },
    { label: "Staff Members", value: staff.length, icon: "👨‍🍳", color: "#d1fae5", sub: `${staff.filter((s) => s.status === "Active").length} on duty` },
  ];

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#f1f5f9", fontFamily: "Poppins, sans-serif" }}>
      {/* Sidebar */}
      <aside style={{
        width: sidebarOpen ? 240 : 70, background: DARK, transition: "width 0.3s",
        display: "flex", flexDirection: "column", flexShrink: 0, position: "sticky", top: 0, height: "100vh",
      }}>
        <div style={{ padding: "24px 16px 20px", borderBottom: "1px solid rgba(255,255,255,0.08)", display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 38, height: 38, background: P, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>🍴</div>
          {sidebarOpen && <span style={{ color: "#fff", fontWeight: 700, fontSize: 14, lineHeight: 1.2 }}>Beef With<br />Chef Melbin</span>}
        </div>

        <nav style={{ flex: 1, padding: "16px 10px" }}>
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              style={{
                width: "100%", display: "flex", alignItems: "center", gap: 12, padding: "11px 12px",
                borderRadius: 10, border: "none", cursor: "pointer", marginBottom: 4, textAlign: "left",
                background: tab === item.id ? P : "transparent",
                color: tab === item.id ? "#fff" : "rgba(255,255,255,0.6)",
                fontWeight: tab === item.id ? 600 : 400, fontSize: 14, transition: "all 0.2s",
                fontFamily: "Poppins, sans-serif",
              }}
              onMouseEnter={(e) => { if (tab !== item.id) e.currentTarget.style.background = "rgba(255,255,255,0.08)"; }}
              onMouseLeave={(e) => { if (tab !== item.id) e.currentTarget.style.background = "transparent"; }}
            >
              <span style={{ fontSize: 18, flexShrink: 0 }}>{item.icon}</span>
              {sidebarOpen && item.label}
            </button>
          ))}
        </nav>

        <div style={{ padding: "12px 10px 20px", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          <button
            onClick={() => navigate("/login")}
            style={{ width: "100%", display: "flex", alignItems: "center", gap: 12, padding: "11px 12px", borderRadius: 10, border: "none", cursor: "pointer", background: "transparent", color: "rgba(255,255,255,0.5)", fontSize: 14, fontFamily: "Poppins, sans-serif" }}
            onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(255,255,255,0.08)"; e.currentTarget.style.color = "#fff"; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "rgba(255,255,255,0.5)"; }}
          >
            <span style={{ fontSize: 18 }}>🚪</span>
            {sidebarOpen && "Logout"}
          </button>
        </div>
      </aside>

      {/* Main */}
      <div style={{ flex: 1, overflow: "auto" }}>
        {/* Topbar */}
        <header style={{ background: "#fff", padding: "0 28px", height: 64, display: "flex", alignItems: "center", justifyContent: "space-between", boxShadow: "0 1px 6px rgba(0,0,0,0.06)", position: "sticky", top: 0, zIndex: 100 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              style={{ background: "none", border: "none", cursor: "pointer", fontSize: 20, padding: 4, color: "#555" }}
              aria-label="Toggle sidebar"
            >
              ☰
            </button>
            <h1 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: DARK }}>
              {NAV_ITEMS.find((n) => n.id === tab)?.label}
            </h1>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ textAlign: "right" }}>
              <p style={{ margin: 0, fontWeight: 600, fontSize: 14, color: DARK }}>Admin</p>
              <p style={{ margin: 0, fontSize: 12, color: "#888" }}>admin@gmail.com</p>
            </div>
            <div style={{ width: 38, height: 38, background: P, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700 }}>A</div>
          </div>
        </header>

        {/* Content */}
        <main style={{ padding: 28 }}>
          {tab === "overview" && (
            <>
              <p style={{ color: "#888", marginBottom: 24, fontSize: 15 }}>Welcome back, Admin 👋 Here's your restaurant summary.</p>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 18, marginBottom: 32 }}>
                {stats.map((s) => (
                  <Card key={s.label}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                      <div>
                        <p style={{ color: "#888", fontSize: 13, margin: "0 0 6px" }}>{s.label}</p>
                        <h2 style={{ margin: "0 0 4px", fontSize: 32, fontWeight: 700, color: DARK }}>{s.value}</h2>
                        <p style={{ margin: 0, fontSize: 12, color: "#aaa" }}>{s.sub}</p>
                      </div>
                      <div style={{ width: 48, height: 48, background: s.color, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>
                        {s.icon}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }} className="overview-grid">
                <Card>
                  <h3 style={{ fontWeight: 700, marginBottom: 16, fontSize: 16, color: DARK }}>Recent Orders</h3>
                  {orders.slice(0, 4).map((o) => (
                    <div key={o.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: "1px solid #f1f5f9" }}>
                      <div>
                        <p style={{ margin: 0, fontWeight: 600, fontSize: 14 }}>{o.customer} <span style={{ color: P, fontSize: 13 }}>{o.id}</span></p>
                        <p style={{ margin: 0, fontSize: 12, color: "#888" }}>{o.type} · {o.branch}</p>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <p style={{ margin: 0, fontWeight: 700, color: P }}>₹{o.amount}</p>
                        <Badge label={o.status} color="" />
                      </div>
                    </div>
                  ))}
                </Card>

                <Card>
                  <h3 style={{ fontWeight: 700, marginBottom: 16, fontSize: 16, color: DARK }}>Order Types Today</h3>
                  {(["Dine In", "Delivery", "Takeaway"] as const).map((type) => {
                    const count = orders.filter((o) => o.type === type && o.date === "2026-07-21").length;
                    const pct = Math.round((count / orders.filter((o) => o.date === "2026-07-21").length) * 100) || 0;
                    return (
                      <div key={type} style={{ marginBottom: 18 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                          <span style={{ fontSize: 14, fontWeight: 600 }}>{type}</span>
                          <span style={{ fontSize: 13, color: "#888" }}>{count} orders ({pct}%)</span>
                        </div>
                        <div style={{ height: 8, background: "#f1f5f9", borderRadius: 4 }}>
                          <div style={{ height: "100%", width: `${pct}%`, background: P, borderRadius: 4, transition: "width 0.6s" }} />
                        </div>
                      </div>
                    );
                  })}

                  <h3 style={{ fontWeight: 700, margin: "24px 0 14px", fontSize: 16, color: DARK }}>Top Menu Items</h3>
                  {menu.filter((m) => m.status === "Available").slice(0, 3).map((m) => (
                    <div key={m.id} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid #f1f5f9" }}>
                      <span style={{ fontSize: 14 }}>{m.name}</span>
                      <span style={{ fontWeight: 700, color: P }}>₹{m.price}</span>
                    </div>
                  ))}
                </Card>
              </div>
            </>
          )}

          {tab === "branches" && <BranchesSection branches={branches} setBranches={setBranches} />}
          {tab === "menu" && <MenuSection menu={menu} setMenu={setMenu} branches={branches} />}
          {tab === "orders" && <OrdersSection orders={orders} setOrders={setOrders} />}
          {tab === "staff" && <StaffSection staff={staff} setStaff={setStaff} branches={branches} />}
        </main>
      </div>

      <style>{`
        @keyframes popIn {
          from { transform: scale(0.93); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        @media (max-width: 768px) {
          .overview-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}
