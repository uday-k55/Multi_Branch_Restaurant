import { useState } from "react";
import { Link } from "react-router-dom";
import Footer from "../components/Footer";

const INFO = [
  { icon: "📞", title: "Call Us", lines: ["+91 9876543210", "+91 9876543211"] },
  { icon: "✉️", title: "Email Us", lines: ["info@chefmelbin.com", "support@chefmelbin.com"] },
  { icon: "📍", title: "Visit Us", lines: ["Chef Melbin Restaurant,", "Kottayam, Kerala, India"] },
  { icon: "🕐", title: "Working Hours", lines: ["Mon - Sat: 11AM - 11PM", "Sunday: 12PM - 10PM"] },
];

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!form.email.trim() || !/\S+@\S+\.\S+/.test(form.email)) e.email = "Valid email required";
    if (!form.subject.trim()) e.subject = "Subject is required";
    if (!form.message.trim()) e.message = "Message is required";
    return e;
  };

  const handleSubmit = (ev: React.FormEvent) => {
    ev.preventDefault();
    const e = validate();
    if (Object.keys(e).length > 0) { setErrors(e); return; }
    setSubmitted(true);
  };

  return (
    <div>
      {/* Page Header */}
      <div style={{
        background: `linear-gradient(rgba(15,23,43,0.85), rgba(15,23,43,0.85)), url("https://images.unsplash.com/photo-1514933651103-005eec06c04b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwaW50ZXJpb3IlMjBkaW5pbmd8ZW58MXx8fHwxNzg0NTY4NzIxfDA&ixlib=rb-4.1.0&q=80&w=1080")`,
        backgroundSize: "cover", backgroundPosition: "center",
        padding: "160px 24px 80px", textAlign: "center",
      }}>
        <h1 style={{ color: "#fff", fontSize: "clamp(32px,5vw,56px)", fontWeight: 700, marginBottom: 16 }}>Contact Us</h1>
        <div style={{ display: "flex", justifyContent: "center", gap: 8, alignItems: "center", fontSize: 15 }}>
          <Link to="/" style={{ color: "#FEA116", textDecoration: "none" }}>Home</Link>
          <span style={{ color: "rgba(255,255,255,0.5)" }}>/</span>
          <span style={{ color: "#fff" }}>Contact</span>
        </div>
      </div>

      {/* Contact Cards */}
      <section style={{ padding: "90px 0 60px" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
          <div style={{ textAlign: "center", marginBottom: 60 }}>
            <p style={{ color: "#FEA116", fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", fontSize: 14, marginBottom: 12 }}>Contact Details</p>
            <h2 style={{ fontSize: "clamp(28px,4vw,42px)", fontWeight: 700, color: "#0F172B" }}>We'd Love To Hear From You</h2>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 24, marginBottom: 70 }}>
            {INFO.map((c) => (
              <div
                key={c.title}
                style={{ background: "#fff", borderRadius: 16, padding: "32px 24px", textAlign: "center", boxShadow: "0 5px 25px rgba(0,0,0,0.06)", transition: "transform 0.3s, box-shadow 0.3s" }}
                onMouseEnter={(e) => { const el = e.currentTarget; el.style.transform = "translateY(-5px)"; el.style.boxShadow = "0 20px 40px rgba(0,0,0,0.1)"; }}
                onMouseLeave={(e) => { const el = e.currentTarget; el.style.transform = "translateY(0)"; el.style.boxShadow = "0 5px 25px rgba(0,0,0,0.06)"; }}
              >
                <div style={{ width: 60, height: 60, background: "rgba(254,161,22,0.1)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 18px", fontSize: 26 }}>
                  {c.icon}
                </div>
                <h5 style={{ fontWeight: 700, marginBottom: 10, fontSize: 16 }}>{c.title}</h5>
                {c.lines.map((l) => <p key={l} style={{ color: "#6c757d", margin: "3px 0", fontSize: 14 }}>{l}</p>)}
              </div>
            ))}
          </div>

          {/* Map + Form */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40, alignItems: "start" }} className="contact-grid">
            <div style={{ borderRadius: 16, overflow: "hidden", boxShadow: "0 5px 25px rgba(0,0,0,0.08)", height: 450 }}>
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d125745.74853037968!2d76.44474753066374!3d9.591566835154378!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b062ba16c6b4b9f%3A0xc405b2cd919eec8e!2sKottayam%2C%20Kerala!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0, display: "block" }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Location map"
              />
            </div>

            <div style={{ background: "#fff", borderRadius: 16, padding: "40px 36px", boxShadow: "0 5px 25px rgba(0,0,0,0.08)" }}>
              <h4 style={{ fontWeight: 700, marginBottom: 28, fontSize: 22, color: "#0F172B" }}>Send Message</h4>

              {submitted ? (
                <div style={{ background: "#d1fae5", border: "1px solid #6ee7b7", borderRadius: 10, padding: "20px 24px", animation: "slideDown 0.4s ease-out" }}>
                  <p style={{ color: "#065f46", fontWeight: 600, margin: 0, fontSize: 16 }}>
                    ✅ Thank you! Your message has been sent. We'll get back to you shortly.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
                    {(["name", "email"] as const).map((field) => (
                      <div key={field}>
                        <label style={{ display: "block", fontWeight: 600, marginBottom: 8, fontSize: 14, color: "#374151" }}>
                          {field === "name" ? "Your Name" : "Email Address"}
                        </label>
                        <input
                          type={field === "email" ? "email" : "text"}
                          value={form[field]}
                          onChange={(e) => { setForm((f) => ({ ...f, [field]: e.target.value })); setErrors((err) => ({ ...err, [field]: "" })); }}
                          placeholder={field === "name" ? "John Doe" : "john@example.com"}
                          style={{
                            width: "100%", height: 48, padding: "0 16px", border: `1px solid ${errors[field] ? "#ef4444" : "#e2e8f0"}`,
                            borderRadius: 8, fontSize: 15, outline: "none", transition: "border-color 0.2s",
                            fontFamily: "Poppins, sans-serif",
                          }}
                          onFocus={(e) => { e.target.style.borderColor = "#FEA116"; }}
                          onBlur={(e) => { e.target.style.borderColor = errors[field] ? "#ef4444" : "#e2e8f0"; }}
                        />
                        {errors[field] && <p style={{ color: "#ef4444", fontSize: 12, marginTop: 4 }}>{errors[field]}</p>}
                      </div>
                    ))}
                  </div>
                  <div style={{ marginBottom: 16 }}>
                    <label style={{ display: "block", fontWeight: 600, marginBottom: 8, fontSize: 14, color: "#374151" }}>Subject</label>
                    <input
                      type="text"
                      value={form.subject}
                      onChange={(e) => { setForm((f) => ({ ...f, subject: e.target.value })); setErrors((err) => ({ ...err, subject: "" })); }}
                      placeholder="How can we help?"
                      style={{ width: "100%", height: 48, padding: "0 16px", border: `1px solid ${errors.subject ? "#ef4444" : "#e2e8f0"}`, borderRadius: 8, fontSize: 15, outline: "none", fontFamily: "Poppins, sans-serif" }}
                      onFocus={(e) => { e.target.style.borderColor = "#FEA116"; }}
                      onBlur={(e) => { e.target.style.borderColor = errors.subject ? "#ef4444" : "#e2e8f0"; }}
                    />
                    {errors.subject && <p style={{ color: "#ef4444", fontSize: 12, marginTop: 4 }}>{errors.subject}</p>}
                  </div>
                  <div style={{ marginBottom: 24 }}>
                    <label style={{ display: "block", fontWeight: 600, marginBottom: 8, fontSize: 14, color: "#374151" }}>Message</label>
                    <textarea
                      value={form.message}
                      onChange={(e) => { setForm((f) => ({ ...f, message: e.target.value })); setErrors((err) => ({ ...err, message: "" })); }}
                      placeholder="Your message here..."
                      rows={5}
                      style={{ width: "100%", padding: "12px 16px", border: `1px solid ${errors.message ? "#ef4444" : "#e2e8f0"}`, borderRadius: 8, fontSize: 15, outline: "none", resize: "vertical", fontFamily: "Poppins, sans-serif" }}
                      onFocus={(e) => { e.target.style.borderColor = "#FEA116"; }}
                      onBlur={(e) => { e.target.style.borderColor = errors.message ? "#ef4444" : "#e2e8f0"; }}
                    />
                    {errors.message && <p style={{ color: "#ef4444", fontSize: 12, marginTop: 4 }}>{errors.message}</p>}
                  </div>
                  <button
                    type="submit"
                    style={{ width: "100%", padding: "15px", background: "#FEA116", color: "#fff", border: "none", borderRadius: 10, fontWeight: 700, fontSize: 16, cursor: "pointer", transition: "background 0.3s", letterSpacing: 1, fontFamily: "Poppins, sans-serif" }}
                    onMouseEnter={(e) => { (e.target as HTMLElement).style.background = "#e08a00"; }}
                    onMouseLeave={(e) => { (e.target as HTMLElement).style.background = "#FEA116"; }}
                  >
                    SEND MESSAGE ✈
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      <Footer />

      <style>{`
        @keyframes slideDown {
          from { transform: translateY(-15px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        @media (max-width: 768px) {
          .contact-grid { grid-template-columns: 1fr !important; }
          .contact-grid > div:first-child { display: none; }
        }
      `}</style>
    </div>
  );
}
