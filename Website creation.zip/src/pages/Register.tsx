import { useState } from "react";
import { Link } from "react-router-dom";

const BG = "https://images.unsplash.com/photo-1535850452425-140ee4a8dbae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwZm9vZCUyMGhlcm8lMjBkYXJrJTIwYW1iaWFuY2V8ZW58MXx8fHwxNzg0NTY4NzIxfDA&ixlib=rb-4.1.0&q=80&w=1080";

export default function Register() {
  const [form, setForm] = useState({ firstName: "", lastName: "", email: "", gender: "", password: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [done, setDone] = useState(false);
  const [showPw, setShowPw] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.firstName.trim()) e.firstName = "First name required";
    if (!form.lastName.trim()) e.lastName = "Last name required";
    if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) e.email = "Valid email required";
    if (!form.gender) e.gender = "Please select a gender";
    if (!form.password || form.password.length < 6) e.password = "Password min 6 characters";
    return e;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setDone(true);
  };

  const field = (name: keyof typeof form, label: string, type = "text", placeholder = "") => (
    <div>
      <label style={{ display: "block", fontWeight: 600, marginBottom: 7, fontSize: 14 }}>{label}</label>
      <input
        type={type === "password" && !showPw ? "password" : type === "password" ? "text" : type}
        value={form[name]}
        onChange={(e) => { setForm((f) => ({ ...f, [name]: e.target.value })); setErrors((err) => ({ ...err, [name]: "" })); }}
        placeholder={placeholder || label}
        style={{
          width: "100%", height: 50, padding: "0 16px", border: `1px solid ${errors[name] ? "#ef4444" : "#e2e8f0"}`,
          borderRadius: 10, fontSize: 15, outline: "none", fontFamily: "Poppins, sans-serif",
        }}
        onFocus={(e) => { e.target.style.borderColor = "#FEA116"; }}
        onBlur={(e) => { e.target.style.borderColor = errors[name] ? "#ef4444" : "#e2e8f0"; }}
      />
      {errors[name] && <p style={{ color: "#ef4444", fontSize: 12, marginTop: 4 }}>{errors[name]}</p>}
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <section style={{
        flex: 1, display: "flex", alignItems: "center",
        background: `linear-gradient(rgba(15,23,43,0.92), rgba(15,23,43,0.92)), url("${BG}")`,
        backgroundSize: "cover", backgroundPosition: "center", padding: "100px 24px 60px",
      }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", width: "100%", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center" }} className="auth-grid">
          {/* Left */}
          <div style={{ color: "#fff" }}>
            <h1 style={{ fontSize: "clamp(30px,4.5vw,52px)", fontWeight: 700, marginBottom: 20, lineHeight: 1.15 }}>
              Create Your Account
            </h1>
            <p style={{ fontSize: 17, color: "#ddd", lineHeight: 1.75, marginBottom: 40, maxWidth: 400 }}>
              Join Beef With Chef Melbin and enjoy delicious food, QR ordering, home delivery, takeaway, and exclusive offers.
            </p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, maxWidth: 380 }}>
              {[
                ["🍽️", "Dine In", "Reserve your table easily"],
                ["🛵", "Delivery", "Fast to your doorstep"],
                ["📦", "Takeaway", "Skip the wait"],
                ["📱", "QR Order", "Scan & order instantly"],
              ].map(([icon, title, sub]) => (
                <div key={String(title)} style={{ background: "rgba(255,255,255,0.08)", borderRadius: 12, padding: "16px", backdropFilter: "blur(4px)" }}>
                  <div style={{ fontSize: 24, marginBottom: 8 }}>{icon}</div>
                  <h6 style={{ color: "#FEA116", fontWeight: 700, marginBottom: 4, fontSize: 14 }}>{title}</h6>
                  <p style={{ color: "#ccc", fontSize: 12, margin: 0 }}>{sub}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Card */}
          <div style={{ background: "#fff", borderRadius: 20, padding: "40px 40px 44px", boxShadow: "0 30px 80px rgba(0,0,0,0.3)" }}>
            {done ? (
              <div style={{ textAlign: "center", padding: "20px 0" }}>
                <div style={{ fontSize: 60, marginBottom: 20 }}>🎉</div>
                <h3 style={{ fontWeight: 700, marginBottom: 12, color: "#0F172B" }}>Account Created!</h3>
                <p style={{ color: "#666", marginBottom: 28 }}>Welcome aboard! You can now log in and start ordering.</p>
                <Link
                  to="/login"
                  style={{ background: "#FEA116", color: "#fff", textDecoration: "none", padding: "13px 32px", borderRadius: 10, fontWeight: 600, fontSize: 16, display: "inline-block" }}
                >
                  Go to Login
                </Link>
              </div>
            ) : (
              <>
                <div style={{ textAlign: "center", marginBottom: 28 }}>
                  <div style={{ width: 66, height: 66, background: "rgba(254,161,22,0.1)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px", fontSize: 30 }}>
                    ➕
                  </div>
                  <h2 style={{ fontWeight: 700, fontSize: 24, marginBottom: 4 }}>Create Account</h2>
                  <p style={{ color: "#888", fontSize: 14 }}>Register to continue</p>
                </div>

                <form onSubmit={handleSubmit}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 14 }}>
                    {field("firstName", "First Name")}
                    {field("lastName", "Last Name")}
                  </div>

                  <div style={{ marginBottom: 14 }}>
                    {field("email", "Email Address", "email", "Enter Email")}
                  </div>

                  <div style={{ marginBottom: 14 }}>
                    <label style={{ display: "block", fontWeight: 600, marginBottom: 7, fontSize: 14 }}>Gender</label>
                    <div style={{ display: "flex", gap: 24 }}>
                      {["Male", "Female", "Other"].map((g) => (
                        <label key={g} style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer", fontSize: 15 }}>
                          <input
                            type="radio"
                            name="gender"
                            value={g}
                            checked={form.gender === g}
                            onChange={() => { setForm((f) => ({ ...f, gender: g })); setErrors((e) => ({ ...e, gender: "" })); }}
                            style={{ accentColor: "#FEA116" }}
                          />
                          {g}
                        </label>
                      ))}
                    </div>
                    {errors.gender && <p style={{ color: "#ef4444", fontSize: 12, marginTop: 4 }}>{errors.gender}</p>}
                  </div>

                  <div style={{ marginBottom: 24, position: "relative" }}>
                    {field("password", "Password", "password", "Create Password")}
                    <button
                      type="button"
                      onClick={() => setShowPw(!showPw)}
                      style={{ position: "absolute", right: 14, top: 38, background: "none", border: "none", cursor: "pointer", fontSize: 16 }}
                    >
                      {showPw ? "🙈" : "👁️"}
                    </button>
                  </div>

                  <button
                    type="submit"
                    style={{ width: "100%", padding: "15px", background: "#FEA116", color: "#fff", border: "none", borderRadius: 10, fontWeight: 700, fontSize: 16, cursor: "pointer", transition: "background 0.3s", fontFamily: "Poppins, sans-serif" }}
                    onMouseEnter={(e) => { (e.target as HTMLElement).style.background = "#e08a00"; }}
                    onMouseLeave={(e) => { (e.target as HTMLElement).style.background = "#FEA116"; }}
                  >
                    Create Account
                  </button>
                </form>

                <hr style={{ margin: "22px 0", borderColor: "#f0f0f0" }} />
                <p style={{ textAlign: "center", margin: 0, fontSize: 15, color: "#555" }}>
                  Already have an account?{" "}
                  <Link to="/login" style={{ color: "#FEA116", textDecoration: "none", fontWeight: 600 }}>
                    Login
                  </Link>
                </p>
              </>
            )}
          </div>
        </div>
      </section>

      <style>{`
        @media (max-width: 768px) {
          .auth-grid { grid-template-columns: 1fr !important; }
          .auth-grid > div:first-child { display: none; }
        }
      `}</style>
    </div>
  );
}
