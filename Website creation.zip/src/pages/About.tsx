import { Link } from "react-router-dom";
import Footer from "../components/Footer";

const CHEFS = [
  {
    name: "Chef Melbin",
    role: "Founder & Master Chef",
    img: "https://images.unsplash.com/photo-1574966740793-953ad374e8fe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVmJTIwY29va2luZyUyMGtpdGNoZW4lMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzg0NTYyMDEzfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    name: "Sarah George",
    role: "Head Dessert Pastry",
    img: "https://images.unsplash.com/photo-1769955817432-641929f613f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHxjaGVmJTIwY29va2luZyUyMGtpdGNoZW4lMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzg0NTYyMDEzfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    name: "Alex John",
    role: "Grill & Steak Expert",
    img: "https://images.unsplash.com/photo-1574966740637-12c84035a4f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxjaGVmJTIwY29va2luZyUyMGtpdGNoZW4lMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzg0NTYyMDEzfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    name: "Mathew Jose",
    role: "Traditional Curry Expert",
    img: "https://images.unsplash.com/photo-1778634304534-6629b945ee26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHw0fHxjaGVmJTIwY29va2luZyUyMGtpdGNoZW4lMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzg0NTYyMDEzfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
];

const STATS = [
  { val: "15+", label: "Years of Experience" },
  { val: "30+", label: "Culinary Specialists" },
  { val: "12+", label: "Active Branches" },
  { val: "50k+", label: "Happy Customers" },
];

const VALUES = [
  {
    icon: "❤️",
    title: "Passion",
    desc: "Every plate we serve is a culinary canvas. We put our heart and soul into creating dishes that leave a lasting memory.",
  },
  {
    icon: "🌿",
    title: "Freshness",
    desc: "We work directly with local farmers and suppliers to ensure only the freshest greens, spices, and premium meat enter our kitchen.",
  },
  {
    icon: "🤝",
    title: "Hospitality",
    desc: "Our guests are our family. We strive to provide a warm, prompt, and friendly dining experience at every single visit.",
  },
];

export default function About() {
  return (
    <div>
      {/* Page Header */}
      <div style={{
        background: `linear-gradient(rgba(15,23,43,0.85), rgba(15,23,43,0.85)), url("https://images.unsplash.com/photo-1514933651103-005eec06c04b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwaW50ZXJpb3IlMjBkaW5pbmd8ZW58MXx8fHwxNzg0NTY4NzIxfDA&ixlib=rb-4.1.0&q=80&w=1080")`,
        backgroundSize: "cover", backgroundPosition: "center",
        padding: "160px 24px 80px", textAlign: "center",
      }}>
        <h1 style={{ color: "#fff", fontSize: "clamp(32px,5vw,56px)", fontWeight: 700, marginBottom: 16 }}>About Us</h1>
        <div style={{ display: "flex", justifyContent: "center", gap: 8, alignItems: "center", fontSize: 15 }}>
          <Link to="/" style={{ color: "#FEA116", textDecoration: "none" }}>Home</Link>
          <span style={{ color: "rgba(255,255,255,0.5)" }}>/</span>
          <span style={{ color: "#fff" }}>About</span>
        </div>
      </div>

      {/* Our Story */}
      <section style={{ padding: "90px 0" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center" }} className="story-grid">
            <div>
              <p style={{ color: "#FEA116", fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", fontSize: 14, marginBottom: 12 }}>
                Our Culinary Journey
              </p>
              <h2 style={{ fontSize: "clamp(26px,3.5vw,38px)", fontWeight: 700, color: "#0F172B", marginBottom: 20 }}>
                Cooking with Passion,<br />Serving with Love
              </h2>
              <p style={{ color: "#555", lineHeight: 1.75, fontSize: 16, marginBottom: 16 }}>
                Welcome to Beef With Chef Melbin, where culinary mastery meets traditional Kerala hospitality. Since our inception, we have been committed to serving delicious, high-quality dishes crafted with passion.
              </p>
              <p style={{ color: "#777", lineHeight: 1.75, fontSize: 15, marginBottom: 32 }}>
                Under the expert guidance of Chef Melbin, we have transformed ordinary dining into an extraordinary experience. We choose the finest cuts of beef, the freshest local spices, and cook each dish to perfection, delivering flavor that leaves our guests coming back for more.
              </p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 36 }}>
                {[{ icon: "🏆", title: "Certified Quality", sub: "A-Grade Ingredients" }, { icon: "🍴", title: "Popular Recipes", sub: "Chef's Signature Blends" }].map((item) => (
                  <div key={item.title} style={{ display: "flex", alignItems: "center", gap: 16 }}>
                    <div style={{ width: 52, height: 52, borderRadius: 10, background: "rgba(254,161,22,0.12)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>
                      {item.icon}
                    </div>
                    <div>
                      <h5 style={{ fontWeight: 700, marginBottom: 2, fontSize: 15 }}>{item.title}</h5>
                      <small style={{ color: "#888" }}>{item.sub}</small>
                    </div>
                  </div>
                ))}
              </div>
              <Link
                to="/contact"
                style={{ background: "#FEA116", color: "#fff", textDecoration: "none", padding: "14px 32px", borderRadius: 8, fontWeight: 600, fontSize: 16, display: "inline-block" }}
              >
                Get in Touch
              </Link>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              {[
                { src: "https://images.unsplash.com/photo-1544025162-d76694265947?w=600", alt: "Cooking Steak", h: 200 },
                { src: "https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=600", alt: "Kitchen Prep", h: 160, mt: 40 },
                { src: "https://images.unsplash.com/photo-1600891964599-f61ba0e24092?w=600", alt: "Food Plate", h: 160 },
                { src: "https://images.unsplash.com/photo-1552566626-52f8b828add9?w=600", alt: "Restaurant", h: 200 },
              ].map((img) => (
                <div key={img.src} style={{ marginTop: img.mt || 0 }}>
                  <img
                    src={img.src}
                    alt={img.alt}
                    style={{ width: "100%", height: img.h, objectFit: "cover", borderRadius: 12, boxShadow: "0 8px 25px rgba(0,0,0,0.1)", transition: "transform 0.4s, box-shadow 0.4s", display: "block" }}
                    onMouseEnter={(e) => { const el = e.target as HTMLElement; el.style.transform = "scale(1.05)"; el.style.boxShadow = "0 15px 35px rgba(0,0,0,0.2)"; }}
                    onMouseLeave={(e) => { const el = e.target as HTMLElement; el.style.transform = "scale(1)"; el.style.boxShadow = "0 8px 25px rgba(0,0,0,0.1)"; }}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section style={{ padding: "90px 0", background: "#f8f9fa" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
          <div style={{ textAlign: "center", marginBottom: 60 }}>
            <p style={{ color: "#FEA116", fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", fontSize: 14, marginBottom: 12 }}>Our Core Values</p>
            <h2 style={{ fontSize: "clamp(28px,4vw,42px)", fontWeight: 700, color: "#0F172B" }}>What Drives Us</h2>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 28 }}>
            {VALUES.map((v) => (
              <div
                key={v.title}
                style={{ background: "#fff", borderRadius: 16, padding: "40px 28px", textAlign: "center", boxShadow: "0 5px 25px rgba(0,0,0,0.06)", transition: "transform 0.3s, box-shadow 0.3s" }}
                onMouseEnter={(e) => { const el = e.currentTarget; el.style.transform = "translateY(-8px)"; el.style.boxShadow = "0 20px 40px rgba(0,0,0,0.1)"; }}
                onMouseLeave={(e) => { const el = e.currentTarget; el.style.transform = "translateY(0)"; el.style.boxShadow = "0 5px 25px rgba(0,0,0,0.06)"; }}
              >
                <div style={{ width: 72, height: 72, background: "rgba(254,161,22,0.1)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px", fontSize: 32 }}>
                  {v.icon}
                </div>
                <h4 style={{ fontWeight: 700, marginBottom: 14, fontSize: 20 }}>{v.title}</h4>
                <p style={{ color: "#6c757d", lineHeight: 1.7, fontSize: 15 }}>{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section style={{ padding: "80px 24px", background: "#0F172B" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 40, textAlign: "center" }}>
          {STATS.map((s) => (
            <div key={s.label}>
              <div style={{ fontSize: "clamp(36px,5vw,56px)", fontWeight: 700, color: "#FEA116", marginBottom: 8 }}>{s.val}</div>
              <p style={{ color: "#aaa", textTransform: "uppercase", letterSpacing: 1, fontSize: 13 }}>{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Chefs */}
      <section style={{ padding: "90px 0" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px" }}>
          <div style={{ textAlign: "center", marginBottom: 60 }}>
            <p style={{ color: "#FEA116", fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", fontSize: 14, marginBottom: 12 }}>Our Culinary Masters</p>
            <h2 style={{ fontSize: "clamp(28px,4vw,42px)", fontWeight: 700, color: "#0F172B" }}>Meet Our Chefs</h2>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))", gap: 28 }}>
            {CHEFS.map((chef) => (
              <div
                key={chef.name}
                style={{ background: "#fff", borderRadius: 16, overflow: "hidden", boxShadow: "0 5px 25px rgba(0,0,0,0.07)", transition: "transform 0.3s, box-shadow 0.3s" }}
                onMouseEnter={(e) => { const el = e.currentTarget; el.style.transform = "translateY(-6px)"; el.style.boxShadow = "0 20px 40px rgba(0,0,0,0.12)"; }}
                onMouseLeave={(e) => { const el = e.currentTarget; el.style.transform = "translateY(0)"; el.style.boxShadow = "0 5px 25px rgba(0,0,0,0.07)"; }}
              >
                <div style={{ height: 280, overflow: "hidden" }}>
                  <img
                    src={chef.img}
                    alt={chef.name}
                    style={{ width: "100%", height: "100%", objectFit: "cover", transition: "transform 0.5s" }}
                    onMouseEnter={(e) => { (e.target as HTMLElement).style.transform = "scale(1.1)"; }}
                    onMouseLeave={(e) => { (e.target as HTMLElement).style.transform = "scale(1)"; }}
                  />
                </div>
                <div style={{ padding: "20px 20px 24px", textAlign: "center" }}>
                  <h5 style={{ fontWeight: 700, marginBottom: 4, fontSize: 17 }}>{chef.name}</h5>
                  <p style={{ color: "#888", fontSize: 14, marginBottom: 16 }}>{chef.role}</p>
                  <div style={{ display: "flex", justifyContent: "center", gap: 8 }}>
                    {["f", "in", "t"].map((s) => (
                      <a
                        key={s}
                        href="#"
                        style={{ width: 32, height: 32, border: "1px solid #FEA116", borderRadius: "50%", display: "inline-flex", alignItems: "center", justifyContent: "center", color: "#FEA116", textDecoration: "none", fontSize: 12, fontWeight: 600, transition: "0.3s" }}
                        onMouseEnter={(e) => { const el = e.currentTarget; el.style.background = "#FEA116"; el.style.color = "#fff"; }}
                        onMouseLeave={(e) => { const el = e.currentTarget; el.style.background = "transparent"; el.style.color = "#FEA116"; }}
                      >
                        {s}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />

      <style>{`
        @media (max-width: 768px) {
          .story-grid { grid-template-columns: 1fr !important; }
          .story-grid > div:last-child { display: none; }
        }
      `}</style>
    </div>
  );
}
