import image_hut from "@/imports/hut.jpg";
import image_food1 from "@/imports/food1.jpg";
import image_hero_1 from "@/imports/hero-1.png";
import { useState } from "react";
import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  MapPin,
  Phone,
  Mail,
  Facebook,
  Instagram,
  Youtube,
  Twitter,
  UtensilsCrossed,
  Truck,
  ShoppingBag,
  QrCode,
} from "lucide-react";
import burgerImg from "@/imports/Screenshot_2026-07-16_204756.png";
import heroFoodImg from "@/imports/Screenshot_2026-07-16_204703.png";

const NAV_LINKS = [
  { name: "Home", href: "#" },
  {
    name: "Menu",
    href: "https://www.figma.com/make/ibDwPozbJB5A2xO6IYuWne/Restaurant-Menu-Page-UI?code-node-id=0-9&p=f&t=RjRtoBniFWObmqpH-0&fullscreen=1",
  },
  {
    name: "Branches",
    href: "https://www.figma.com/make/wthxgnwQhbAlRBCSlSoHhD/Design-Branch-Selection-Page?code-node-id=0-9&p=f&t=pIvci3LOvSIKldM3-0&fullscreen=1",
  },
  { name: "About", href: "#" },
  { name: "Contact", href: "#" },
];

const SERVICES = [
  {
    icon: <UtensilsCrossed className="w-8 h-8" />,
    title: "Dine In",
    desc: "Reserve a seat or scan the QR code on your table to place your orders from your phone and place orders instantly.",
  },
  {
    icon: <Truck className="w-8 h-8" />,
    title: "Home Delivery",
    desc: "Your favourite restaurant delivers directly to your home with estimated delivery time confirmation.",
  },
  {
    icon: <ShoppingBag className="w-8 h-8" />,
    title: "Take Away",
    desc: "Order in advance, pick you food and enjoy it find without waiting.",
  },
  {
    icon: <QrCode className="w-8 h-8" />,
    title: "QR Ordering",
    desc: "Scan the QR code at your table and place your order without calling staff!",
  },
];

const FAQS = [
  {
    q: "How does QR Ordering work?",
    a: "Simply scan the QR code at your table using your phone's camera, browse the menu, and place your order — no app download needed.",
  },
  {
    q: "Can I order from delivery?",
    a: "Yes! We offer home delivery to your location. Select your nearest branch and place an order through our platform.",
  },
  {
    q: "Can I place the order online and collect it from the nearest branch?",
    a: "Yes. Place the order online and collect it from the nearest branch.",
  },
];

import image_hero from "@/imports/hero.png";
export default function App() {
  const [openFaq, setOpenFaq] = useState<number | null>(2);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="min-h-screen font-['Poppins',sans-serif] bg-white">
      {/* NAVBAR */}
      <nav className="bg-[#1a1f2e] sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <UtensilsCrossed className="w-6 h-6 text-[#f5a623]" />
            <span className="text-white font-bold text-lg leading-tight">
              Beef With Chef Melbin
            </span>
          </div>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map((link) => (
              <a
                key={link.name}
                href={link.href}
                target={
                  link.href.startsWith("http")
                    ? "_blank"
                    : "_self"
                }
                rel="noopener noreferrer"
                className={`text-sm font-medium transition-colors ${
                  link.name === "Home"
                    ? "text-[#f5a623]"
                    : "text-gray-300 hover:text-white"
                }`}
              >
                {link.name}
              </a>
            ))}
<a
  href="https://www.figma.com/make/5t2W583oG0yeJu3odWVcUW/Design-Login-Page?code-node-id=0-6&p=f&t=nMWhFn6sosl0E2nd-0&fullscreen=1"
  target="_blank"
  rel="noopener noreferrer"
>
  <button className="bg-[#f5a623] hover:bg-[#e09615] text-white text-sm font-semibold px-5 py-2 rounded-md transition-colors">
    Login
  </button>
</a>

          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden text-white"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            <div className="w-5 h-0.5 bg-white mb-1" />
            <div className="w-5 h-0.5 bg-white mb-1" />
            <div className="w-5 h-0.5 bg-white" />
          </button>
        </div>

        {menuOpen && (
          <div className="md:hidden bg-[#1a1f2e] px-4 pb-4 flex flex-col gap-3">
            {NAV_LINKS.map((link) => (
              <a
                key={link.name}
                href={link.href}
                target={
                  link.href.startsWith("http")
                    ? "_blank"
                    : "_self"
                }
                rel="noopener noreferrer"
                className="text-gray-300 text-sm hover:text-white"
              >
                {link.name}
              </a>
            ))}
            <button className="bg-[#f5a623] text-white text-sm font-semibold px-5 py-2 rounded-md w-fit">
              Login
            </button>
          </div>
        )}
      </nav>

      {/* HERO */}
      <section className="bg-[#1a1f2e] py-16 sm:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-white text-4xl sm:text-5xl font-extrabold leading-tight mb-4">
              Order Delicious Food From Your Favourite
              Restaurant Branch
            </h1>
            <p className="text-gray-400 text-base mb-8">
              Enjoy Dine-In, Home Delivery, Takeaway and QR
              Table Ordering from multiple restaurant branches
              with one easy platform.
            </p>
            <div className="flex gap-4 flex-wrap">
              <button className="bg-[#2d3345] hover:bg-[#363d55] text-white font-semibold px-6 py-3 rounded-md flex items-center gap-2 transition-colors">
                <QrCode className="w-5 h-5" />
                Scan QR
              </button>
              <button className="border border-gray-500 hover:border-gray-300 text-white font-semibold px-6 py-3 rounded-md transition-colors">
                Select Branch
              </button>
            </div>
          </div>

          {/* Circular food image */}
          <div className="flex justify-center">
            <div className="w-72 h-72 sm:w-96 sm:h-96 rounded-full overflow-hidden border-4 border-[#f5a623]/30 shadow-2xl">
              <img
                src={image_hero_1}
                alt="Grilled food on BBQ"
                className="w-full h-full object-cover scale-150 object-center"
              />
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 text-center">
          <p className="text-[#f5a623] text-sm font-semibold uppercase tracking-widest mb-1">
            OUR SERVICES
          </p>
          <h2 className="text-3xl font-bold text-gray-900 mb-10">
            Everything You Need
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {SERVICES.map((s) => (
              <div
                key={s.title}
                className="border border-gray-100 rounded-xl p-6 hover:shadow-md transition-shadow text-center"
              >
                <div className="flex justify-center mb-3 text-[#f5a623]">
                  {s.icon}
                </div>
                <h3 className="font-semibold text-gray-800 text-sm mb-2">
                  {s.title}
                </h3>
                <p className="text-gray-500 text-xs leading-relaxed">
                  {s.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TODAY'S BEST DEALS */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 text-center">
          <p className="text-[#f5a623] text-sm font-semibold uppercase tracking-widest mb-1">
            TODAY&apos;S SPECIAL OFFER
          </p>
          <h2 className="text-3xl font-bold text-gray-900 mb-8">
            Today&apos;s Best Deals
          </h2>

          <div className="relative rounded-2xl overflow-hidden shadow-xl">
            <img
              src={image_food1}
              alt="Juicy burger deal"
              className="w-full h-72 sm:h-96 object-cover object-center"
            />
            {/* Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col items-center justify-end pb-12 px-4">
              <h3 className="text-white text-3xl sm:text-4xl font-extrabold mb-1">
                20% <span className="text-[#f5a623]">OFF</span>{" "}
                On Burgers
              </h3>
              <p className="text-gray-300 text-sm mb-5">
                Available only today
              </p>
              <button className="bg-[#f5a623] hover:bg-[#e09615] text-white font-semibold px-8 py-3 rounded-md transition-colors">
                Order Now
              </button>
              <div className="flex gap-3 mt-6">
                <img
                  src={image_hero}
                  alt="Burger slide 1"
                  className="w-14 h-14 rounded-lg object-cover border-2 border-[#f5a623] cursor-pointer"
                />
                <img
                  src={image_hero_1}
                  alt="Burger slide 2"
                  className="w-14 h-14 rounded-lg object-cover border-2 border-white/40 cursor-pointer hover:border-[#f5a623] transition-colors"
                />
              </div>
            </div>

            {/* Carousel arrows */}
            <button className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/40 text-white rounded-full p-2 transition-colors">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/40 text-white rounded-full p-2 transition-colors">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 grid md:grid-cols-2 gap-12 items-start">
          {/* Restaurant interior image */}
          <div className="rounded-2xl overflow-hidden shadow-lg h-72 md:h-full">
            <img
              src={image_hut}
              alt="Restaurant interior"
              className="w-full h-full object-cover"
            />
          </div>

          {/* FAQ content */}
          <div>
            <p className="text-[#f5a623] text-sm font-semibold uppercase tracking-widest mb-1">
              WHY CHOOSE US
            </p>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-6">
              Frequently Asked Questions
            </h2>
            <div className="space-y-3">
              {FAQS.map((faq, i) => (
                <div
                  key={i}
                  className="border border-gray-200 rounded-lg overflow-hidden"
                >
                  <button
                    className="w-full flex items-center justify-between px-5 py-4 text-left text-sm font-medium text-gray-800 hover:bg-gray-50 transition-colors"
                    onClick={() =>
                      setOpenFaq(openFaq === i ? null : i)
                    }
                  >
                    {faq.q}
                    <ChevronDown
                      className={`w-4 h-4 text-gray-500 flex-shrink-0 transition-transform ${
                        openFaq === i ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {openFaq === i && (
                    <div className="px-5 pb-4 text-sm text-gray-500 leading-relaxed border-t border-gray-100 bg-gray-50">
                      {faq.a}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#1a1f2e] text-gray-300 pt-14 pb-6">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 grid sm:grid-cols-2 md:grid-cols-4 gap-10 mb-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <UtensilsCrossed className="w-5 h-5 text-[#f5a623]" />
              <span className="text-white font-bold">
                Beef With Chef Melbin
              </span>
            </div>
            <p className="text-xs leading-relaxed text-gray-400">
              Enjoy delicious food with Dine-in, Home Delivery,
              Takeaway and QR Table Ordering.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm">
              Quick Links
            </h4>
            <ul className="space-y-2 text-xs">
              {["Home", "Menu", "Branches", "Contact"].map(
                (l) => (
                  <li key={l}>
                    <a
                      href="#"
                      className="hover:text-[#f5a623] transition-colors"
                    >
                      {l}
                    </a>
                  </li>
                ),
              )}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm">
              Contact
            </h4>
            <ul className="space-y-3 text-xs">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#f5a623] flex-shrink-0 mt-0.5" />
                Melbourn, Kerala
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#f5a623] flex-shrink-0" />
                +91 9876543210
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#f5a623] flex-shrink-0" />
                info@chefmelbin.com
              </li>
            </ul>
          </div>

          {/* Follow Us */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm">
              Follow Us
            </h4>
            <div className="flex gap-3">
              {[Facebook, Instagram, Youtube, Twitter].map(
                (Icon, i) => (
                  <a
                    key={i}
                    href="#"
                    className="w-8 h-8 rounded-full bg-[#2d3345] hover:bg-[#f5a623] flex items-center justify-center transition-colors"
                  >
                    <Icon className="w-4 h-4 text-white" />
                  </a>
                ),
              )}
            </div>
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-4 sm:px-6 border-t border-white/10 pt-5 text-center text-xs text-gray-500">
          © 2024 Beef With Chef Melbin. All Rights Reserved.
        </div>
      </footer>
    </div>
  );
}