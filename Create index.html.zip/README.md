
  # Create index.html

  This is a code bundle for Create index.html. The original project is available at https://www.figma.com/design/ppxFz8A3SR6kj6lBCNuprN/Create-index.html.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  